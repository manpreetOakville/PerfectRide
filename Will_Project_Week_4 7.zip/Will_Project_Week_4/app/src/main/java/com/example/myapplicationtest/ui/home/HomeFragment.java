package com.example.myapplicationtest.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.myapplicationtest.PaymentActivity;
import com.example.myapplicationtest.ProfileActivity;
import com.example.myapplicationtest.R;
import com.example.myapplicationtest.RideDetailsActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HomeFragment extends Fragment {


    private EditText postaltextBox;
    private ImageView Profile;
    private  ImageView Payment;
    private Button RideDetails;


    private Button btnSearch;
    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        postaltextBox = (EditText) root.findViewById(R.id.textbox);
        btnSearch = (Button) root.findViewById(R.id.btnSearch);
        Profile = (ImageView) root.findViewById(R.id.btnProfile);
        Payment = (ImageView) root.findViewById(R.id.btnPayment);




        btnSearch.setVisibility(View.INVISIBLE);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });


        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });


        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  profileIntent = new Intent(getActivity(), ProfileActivity.class);
                startActivity(profileIntent);
            }
        });

        Payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent paymentIntent = new Intent(getActivity(), PaymentActivity.class);
                startActivity(paymentIntent);
            }
        });


        postaltextBox.addTextChangedListener(new TextWatcher()
        {
            private Pattern sPattern
                    = Pattern.compile("[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ] ?[0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]");

            private CharSequence mText;

            private boolean isValid(CharSequence s) {
                return sPattern.matcher(s).matches();
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }


            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after){
                // mText = isValid(s) ? new CharSequence(s) : "";
            }

            @Override
            public void afterTextChanged(Editable s)
            {
                if (!isValid(s))
                {

                    btnSearch.setVisibility(View.VISIBLE);
                }




            }
        });


        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String postalCode = postaltextBox.getText().toString();

             checkPattern(postalCode);

             if(checkPattern(postalCode)){
                 Intent intent = new Intent(getActivity(), RideDetailsActivity.class);
                 startActivity(intent);
             }


            }
        });




        return root;
    }


    public boolean checkPattern(String Code){
      Pattern sPattern
                = Pattern.compile("[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ] ?[0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]");

        Matcher matcher = sPattern.matcher(Code);
        return matcher.matches();



    }
}