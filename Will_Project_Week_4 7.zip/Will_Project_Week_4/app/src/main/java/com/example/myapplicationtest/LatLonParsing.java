package com.example.myapplicationtest;

import java.util.ArrayList;
import java.util.List;


    public class LatLonParsing {


        List<results> results = new ArrayList<results>();

        public class results{

            List<locations> locations = new ArrayList<locations>();

            public class locations{

                latlng latLng;

                public class latlng{


                    Double lat;
                    Double lng;

                    public Double getLat() {
                        return lat;
                    }

                    public void setLat(Double lat) {
                        this.lat = lat;
                    }

                    public Double getLng() {
                        return lng;
                    }

                    public void setLng(Double lng) {
                        this.lng = lng;
                    }






                }
            }
        }


    }


