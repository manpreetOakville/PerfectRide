package com.example.myapplicationtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class PaymentActivity extends AppCompatActivity {

        EditText creditCard;
        EditText expiryDate;

        Button saveButton;
        DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        db = new DatabaseHelper(this);

        creditCard = (EditText) findViewById(R.id.edt_text);
        saveButton = (Button) findViewById(R.id.save_button);
        expiryDate = (EditText) findViewById(R.id.edt_text_2);

        ArrayList<String> listOfPattern=new ArrayList<String>();

        String ptVisa = "^4[0-9]{6,}$";
        listOfPattern.add(ptVisa);
        String ptMasterCard = "^5[1-5][0-9]{5,}$";
        listOfPattern.add(ptMasterCard);
        String ptAmeExp = "^3[47][0-9]{5,}$";
        listOfPattern.add(ptAmeExp);
        String ptDinClb = "^3(?:0[0-5]|[68][0-9])[0-9]{4,}$";
        listOfPattern.add(ptDinClb);
        String ptDiscover = "^6(?:011|5[0-9]{2})[0-9]{3,}$";
        listOfPattern.add(ptDiscover);
        String ptJcb = "^(?:2131|1800|35[0-9]{3})[0-9]{3,}$";
        listOfPattern.add(ptJcb);




        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ccNum = creditCard.getText().toString();
                for(String p:listOfPattern){
                    if(ccNum.matches(p)){
                        Toast.makeText(PaymentActivity.this,"Credit Card Number is Valid",Toast.LENGTH_SHORT).show();
//                      insertDatabase();
                        break;
                    }else {
                        Toast.makeText(PaymentActivity.this,"Credit Card Number is not Valid",Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });








        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    public void insertDatabase(){
        boolean isInserted = db.insertCreditCardInfo(creditCard.getText().toString(),expiryDate.getText().toString());

                        if(isInserted){
                            Toast.makeText(PaymentActivity.this,"Data Inserted",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(PaymentActivity.this,"Data Not Inserted",Toast.LENGTH_SHORT).show();
                        }
    }
}
