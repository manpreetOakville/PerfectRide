package com.example.myapplicationtest;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.TextView;

public class CostCalculateTask extends AsyncTask<Void,Integer,Double> {

    Context context;
    TextView textView;
    Button button;
    Double Cost;
    Double Distance;


    CostCalculateTask(Context context, TextView textView, Button button, Double distance){

        this.context = context;
        this.textView = textView;
        this.button = button;
        this.Distance = distance;

    }


    @Override
    protected Double doInBackground(Void... voids) {

        Cost = Distance * 1;
        return  Cost;

    }


    @Override
    protected void onPostExecute(Double aDouble) {
        textView.setText( String.format("%.2f",Cost)+ "CAD");
        button.setEnabled(true);


    }
}
