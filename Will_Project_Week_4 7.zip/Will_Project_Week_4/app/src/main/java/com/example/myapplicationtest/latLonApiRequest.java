package com.example.myapplicationtest;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface latLonApiRequest {

    @GET("address")
    Call<LatLonParsing> getLocation(@Query("key") String key, @Query("location") String location);

//http://www.mapquestapi.com/geocoding/v1/address?key=KEY&location=1600+Pennsylvania+Ave+NW,Washington,DC,20500

}
