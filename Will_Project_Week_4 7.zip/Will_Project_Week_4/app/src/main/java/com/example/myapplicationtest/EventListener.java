package com.example.myapplicationtest;

public interface EventListener {

    public void sendDataToActivity(String data);

}
