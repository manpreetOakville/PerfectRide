package com.example.myapplicationtest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;

import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RideDetailsActivity extends AppCompatActivity {

    EditText ApiText;
    EditText CostText;
    Button mapbtn;
    String Destination;
    Button confirm;
    EditText distance;
    String DestinationName;
    EditText destination;
    Double distanceInKms;
    String costOfTheTrip = "0.0";
    latLonApiRequest apiRequest;
   Double lon;
    Double lat;

    private FusedLocationProviderClient mFusedLocationClient;
    private TextView txtLocation;

    private int locationRequestCode = 1000;
    private double wayLatitude = 0.0, wayLongitude = 0.0;

    private LocationRequest locationRequest;
    private LocationCallback locationCallback;


    public static final String  TAG = "RideDetailsActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_details);




        CostText = (EditText) findViewById(R.id.edt_costtext);
        confirm = (Button) findViewById(R.id.btnConfirm);
        distance = (EditText)findViewById(R.id.edt_disttext);
        destination = (EditText)findViewById(R.id.edt_desttext);
        mapbtn = (Button) findViewById(R.id.btnMap);
//        ApiText = (EditText) findViewById(R.id.edt_api);

        // Retrofit


        // Cost Calculation






        confirm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DestinationName = destination.getText().toString();

                ExecuteApi();







            }
        });





        Log.d(TAG,"RideDetailsActivity");
        mapbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mapIntent = new Intent(RideDetailsActivity.this, MapsActivity.class);
                startActivity(mapIntent);
            }
        });


// map Quest key dGq1Ms3BHuTNJGqh3xW3vKxey4ornGF4

        // Retrofit code below


        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        requestPermission();

    }



    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }


    public  void requestPermission(){


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    locationRequestCode);

        } else {
            // already permission granted

            mFusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    wayLatitude = location.getLatitude();
                    wayLongitude = location.getLongitude();



                    Log.d(TAG,"longitude"+wayLongitude+"   lattitude:"+wayLatitude);
                }
            });
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1000: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mFusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                        if (location != null) {
                            wayLatitude = location.getLatitude();
                            wayLongitude = location.getLongitude();

//                            Log.d(TAG,"longitude"+wayLongitude+"   lattitude:"+wayLatitude);
                        }
                    });
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }

//dGq1Ms3BHuTNJGqh3xW3vKxey4ornGF4
    public void ExecuteApi(){

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://www.mapquestapi.com/geocoding/v1/").addConverterFactory(GsonConverterFactory.create()).build();
        apiRequest = retrofit.create(latLonApiRequest.class);

        Call<LatLonParsing> call = apiRequest.getLocation("dGq1Ms3BHuTNJGqh3xW3vKxey4ornGF4",DestinationName);


        call.enqueue(new Callback<LatLonParsing>() {
            @Override
            public void onResponse(Call<LatLonParsing> call, Response<LatLonParsing> response) {


                if(response.isSuccessful()){
                    lat = response.body().results.get(0).locations.get(0).latLng.getLat();
                   lon = response.body().results.get(0).locations.get(0).latLng.getLng();

                    distanceInKms = getDistance(wayLatitude,wayLongitude,lat,lon);
                    distance.setText(String.format("%.2f",distanceInKms));


                    CostCalculateTask myTask = new CostCalculateTask(RideDetailsActivity.this,CostText,confirm,distanceInKms);
                    myTask.execute();
                    confirm.setEnabled(false);

                }



            }

            @Override
            public void onFailure(Call<LatLonParsing> call, Throwable t) {
                ApiText.setText(t.getMessage());
            }
        });
    }

    public double getDistance(double startLat, double startLong , double endLat, double endLong){

         Double EARTH_RADIUS = 6371.0;
        double dLat = Math.toRadians(endLat - startLat);
        double dLong = Math.toRadians(endLong - startLong);

        startLat = Math.toRadians(startLat);
        endLat = Math.toRadians(endLat);

        double a = haversin(dLat) + Math.cos(startLat) * Math.cos(endLat)  * haversin(dLong);
        double c = 2 * Math. atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return  EARTH_RADIUS * c;

    }


    public  static double haversin(double val){
        return  Math.pow(Math.sin(val/2),2);
    }
}


